package lk.Ijse.thigakade.dto.tm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.awt.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SupplierOrderTm {
    private String s_id;
    private String rs_id;
    private Integer unit_price;
    private Integer weight;
    private Integer qty;
    private Button btn;
}
