package lk.Ijse.thigakade.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import lk.Ijse.thigakade.dto.RawStockDto;
import lk.Ijse.thigakade.dto.SupplierDto;
import lk.Ijse.thigakade.dto.SupplierOrderDto;
import lk.Ijse.thigakade.dto.tm.SupplierOrderTm;
import lk.Ijse.thigakade.model.RawStockModel;
import lk.Ijse.thigakade.model.SupplierModel;
import lk.Ijse.thigakade.model.SupplierPlaceOrderModel;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierOrderFormController {

    @FXML
    public TextField txtDescription;
    @FXML
    public TextField txtSupllierOrderId;
    @FXML
    public TextField txtQty;
    @FXML
    public TextField txtweight;
    @FXML
    public TextField txtunicPrice;
    @FXML
    public TableView tblSupplierOrder;
    @FXML
    public TableColumn colSupplierOrderId;
    @FXML
    public TableColumn colSupplierId;
    @FXML
    public TableColumn colunicPrice;
    @FXML
    public TableColumn colweight;
    @FXML
    public TableColumn colqty;
    @FXML
    public TableColumn colAction;
    @FXML
    public Label lblweight;
    @FXML
    public Label lblunicPrice;
    @FXML
    public Label lblQty;
    @FXML
    public Label lblDescription;
    @FXML
    public ComboBox<String> cmbRawStockId;
    @FXML
    public Pane btnAddToOrder;
    @FXML
    public Label lblTotal;
    @FXML
    private ComboBox<String> cmbSupplierId;

    @FXML
    private TableColumn<?, ?> colLocation;

    @FXML
    private TableColumn<?, ?> colName;

    @FXML
    private TableColumn<?, ?> colS_id;

    @FXML
    private TableColumn<?, ?> colemail;

    @FXML
    private TableColumn<?, ?> coltel;

    @FXML
    private Label lblSupplierName;

    @FXML
    private TableView<?> tblSupplier;

    @FXML
    private TextField txtlocation;

    @FXML
    private TextField txttel;
    @FXML
    private TextField txtTotalQty;

    private final SupplierPlaceOrderModel supplierPlaceOrderModel = new SupplierPlaceOrderModel();
    private final ObservableList<SupplierOrderTm> obList = FXCollections.observableArrayList();
    private final SupplierModel supplierModel = new SupplierModel();
    private final RawStockModel rawStockModel = new RawStockModel();


    public void initialize() {
        loadSupplierIds();
        loadRawStockIds();
    }

    private void loadRawStockIds() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<RawStockDto> supList = rawStockModel.loadAllRawStock();

            for (RawStockDto dto : supList) {
                obList.add(dto.getRs_id());
            }
            cmbRawStockId.setItems(obList);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void loadSupplierIds() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<SupplierDto> supList = supplierModel.loadAllSupplier();

            for (SupplierDto dto : supList) {
                obList.add(dto.getS_id());
            }
            cmbSupplierId.setItems(obList);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void btnClearOnAction(ActionEvent event) {

    }


    @FXML
    void btnSaveOnAction(ActionEvent event) {
        String id = txtSupllierOrderId.getText();
        String supId = cmbSupplierId.getValue();
        String description = txtDescription.getText();
        int unitPrice = Integer.parseInt(txtunicPrice.getText());
        int weight = Integer.parseInt(txtweight.getText());
        int qty = Integer.parseInt(txtQty.getText());

        List<SupplierOrderTm> tmList = new ArrayList<>();

        for (SupplierOrderTm supplierOrderTm : obList) {
            tmList.add(supplierOrderTm);
        }

        var supplierOrderDto = new SupplierOrderDto(id, supId, description, unitPrice, weight, qty, tmList);

        try {
            boolean isSuccess = supplierPlaceOrderModel.supplierOrder(supplierOrderDto);
            if (isSuccess) {
                new Alert(Alert.AlertType.CONFIRMATION, "order completed!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }


    @FXML
    void btnbackOnAction(ActionEvent event) {

    }

    @FXML
    void cmbSupplierOnAction(ActionEvent event) throws SQLException {
        String id = cmbSupplierId.getValue();
        SupplierDto dto = SupplierModel.searchSupplier(id);

        lblSupplierName.setText(dto.getS_name());

    }

    @FXML
    public void cmbRawStockOnsction(ActionEvent event) {
        String rs_id = cmbRawStockId.getValue();

        // txtQty.requestFocus();

        try {
            RawStockDto dto = rawStockModel.searchRawStock(rs_id);

            lblDescription.setText(dto.getDescription());
            lblunicPrice.setText(String.valueOf(dto.getUnit_price()));
            lblweight.setText(String.valueOf(dto.getWeight()));
            lblQty.setText(String.valueOf(dto.getQuality()));


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void btnAddToOrderOnAction(MouseEvent mouseEvent) {
       /* String rs_id = cmbRawStockId.getValue();
        String description = lblDescription.getText();
        int unitPrice  = Integer.parseInt(lblunicPrice.getText());
        int weight = Integer.parseInt(lblweight.getText());
        int qty = Integer.parseInt(txtTotalQty.getText());
        double total = qty * unitPrice;
        Button btn = new Button("remove");
        btn.setCursor(Cursor.HAND);

        btn.setOnAction((e) -> {
            ButtonType yes = new ButtonType("yes", ButtonBar.ButtonData.OK_DONE);
            ButtonType no = new ButtonType("no", ButtonBar.ButtonData.CANCEL_CLOSE);

            Optional<ButtonType> type = new Alert(Alert.AlertType.INFORMATION, "Are you sure to remove?", yes, no).showAndWait();

            if (type.orElse(no) == yes) {
                int index = tblOrderCart.getSelectionModel().getSelectedIndex();
                obList.remove(index);
                tblOrderCart.refresh();

                calculateNetTotal();
            }
        });

        for (int i = 0; i < tblOrderCart.getItems().size(); i++) {
            if (code.equals(colItemCode.getCellData(i))) {
                qty += (int) colQty.getCellData(i);
                total = qty * unitPrice;

                obList.get(i).setQty(qty);
                obList.get(i).setTot(total);

                tblOrderCart.refresh();
                calculateNetTotal();
                return;
            }
        }

        obList.add(new CartTm(
                code,
                description,
                qty,
                unitPrice,
                total,
                btn
        ));

        tblOrderCart.setItems(obList);
        calculateNetTotal();
        txtQty.clear();
    }

    public void txtQtyOnAction(MouseEvent mouseEvent) {
        btnAddToOrderOnAction(mouseEvent);
    }*/
    }
}