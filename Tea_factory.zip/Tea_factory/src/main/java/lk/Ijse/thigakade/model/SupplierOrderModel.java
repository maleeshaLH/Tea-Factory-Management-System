package lk.Ijse.thigakade.model;

import lk.Ijse.thigakade.db.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SupplierOrderModel {


    public static boolean saveSupplierOrder(String s_id, String su_id, String description, Integer unit_price, Integer weight, Integer qty) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO supplier_order VALUES(?, ?, ?,?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, s_id);
        pstm.setString(2, su_id);
        pstm.setString(3,description);
        pstm.setInt(4,unit_price);
        pstm.setInt(5,weight);
        pstm.setInt(6,qty);

        return pstm.executeUpdate()>0;
    }

}
