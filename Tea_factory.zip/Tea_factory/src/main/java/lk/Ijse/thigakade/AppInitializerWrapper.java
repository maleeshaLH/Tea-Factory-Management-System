package lk.Ijse.thigakade;

public class AppInitializerWrapper {
    public static void main(String []arge){AppInitializer.main(arge);}
}
